#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define RECORD_SIZE sizeof(Record)

typedef struct {
    int year, month, day;
    int hour, minute, second;
    int status;
    int code;
} Record;

// YYYYMMDD holatiga o‘tkazish (taqqoslash uchun)
int date_to_int(int day, int month, int year) { return year * 10000 + month * 100 + day; }

// DD.MM.YYYY formatdan ajratish
int parse_date(const char *str, int *day, int *month, int *year) {
    return sscanf(str, "%d.%d.%d", day, month, year) == 3;
}

int main() {
    char filename[256];
    char date1_str[20], date2_str[20];
    int d1, m1, y1, d2, m2, y2;

    // Fayl nomi
    if (scanf("%255s", filename) != 1) {
        printf("n/a\n");
        return 1;
    }

    // Sana oralig‘i
    if (scanf("%19s %19s", date1_str, date2_str) != 2 || !parse_date(date1_str, &d1, &m1, &y1) ||
        !parse_date(date2_str, &d2, &m2, &y2)) {
        printf("n/a\n");
        return 1;
    }

    int start_date = date_to_int(d1, m1, y1);
    int end_date = date_to_int(d2, m2, y2);

    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        printf("n/a\n");
        return 1;
    }

    // Yangi vaqtinchalik fayl
    FILE *temp = fopen("temp_clear.bin", "wb");
    if (!temp) {
        fclose(fp);
        printf("n/a\n");
        return 1;
    }

    Record rec;
    int ok = 0;

    while (fread(&rec, RECORD_SIZE, 1, fp) == 1) {
        int cur_date = date_to_int(rec.day, rec.month, rec.year);
        // Oralig‘ga kirmasa — yozamiz
        if (cur_date < start_date || cur_date > end_date) {
            fwrite(&rec, RECORD_SIZE, 1, temp);
            ok = 1;
        }
    }

    fclose(fp);
    fclose(temp);

    if (!ok) {
        printf("n/a\n");
        remove("temp_clear.bin");
        return 1;
    }

    // Asl faylni o‘chirib, temp faylni qayta nomlash
    if (remove(filename) != 0 || rename("temp_clear.bin", filename) != 0) {
        printf("n/a\n");
        return 1;
    }

    // Natijaviy faylni ko‘rsatish
    FILE *final = fopen(filename, "rb");
    if (!final) {
        printf("n/a\n");
        return 1;
    }

    while (fread(&rec, RECORD_SIZE, 1, final) == 1) {
        printf("%d %d %d %d %d %d %d %d\n", rec.year, rec.month, rec.day, rec.hour, rec.minute, rec.second,
               rec.status, rec.code);
    }

    fclose(final);
    return 0;
}
