#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define RECORD_SIZE sizeof(Record)

typedef struct {
    int year, month, day;
    int hour, minute, second;
    int status;
    int code;
} Record;

// Funksiya: kiritilgan sana bilan yozuv sanasini solishtirish
int match_date(Record rec, int d, int m, int y) { return (rec.day == d && rec.month == m && rec.year == y); }

// Sana satrini DD.MM.YYYY dan sonlarga ajratish
int parse_date(const char *date_str, int *d, int *m, int *y) {
    return sscanf(date_str, "%d.%d.%d", d, m, y) == 3;
}

int main() {
    char filename[256];
    char date_str[20];
    int d, m, y;

    // Fayl nomi va sana o‘qiladi
    if (scanf("%255s", filename) != 1 || scanf("%19s", date_str) != 1) {
        printf("n/a\n");
        return 1;
    }

    if (!parse_date(date_str, &d, &m, &y)) {
        printf("n/a\n");
        return 1;
    }

    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        printf("n/a\n");
        return 1;
    }

    Record rec;
    int found = 0;

    // Faylni ketma-ket o‘qish
    while (fread(&rec, RECORD_SIZE, 1, fp) == 1) {
        if (match_date(rec, d, m, y)) {
            printf("%d\n", rec.code);
            found = 1;
            break;
        }
    }

    fclose(fp);

    if (!found) printf("n/a\n");

    return 0;
}
