#include <stdio.h>
#include <stdlib.h>

#define RECORD_SIZE sizeof(Record)

typedef struct {
    int year, month, day;
    int hour, minute, second;
    int status;
    int code;
} Record;

int compare(Record a, Record b) {
    if (a.year != b.year) return a.year - b.year;
    if (a.month != b.month) return a.month - b.month;
    if (a.day != b.day) return a.day - b.day;
    if (a.hour != b.hour) return a.hour - b.hour;
    if (a.minute != b.minute) return a.minute - b.minute;
    return a.second - b.second;
}

long get_file_record_count(FILE *fp) {
    fseek(fp, 0, SEEK_END);
    long size = ftell(fp);
    return size / RECORD_SIZE;
}

int read_record(FILE *fp, long index, Record *rec) {
    if (fseek(fp, index * RECORD_SIZE, SEEK_SET) != 0) return 0;
    return fread(rec, RECORD_SIZE, 1, fp) == 1;
}

int write_record(FILE *fp, long index, Record *rec) {
    if (fseek(fp, index * RECORD_SIZE, SEEK_SET) != 0) return 0;
    return fwrite(rec, RECORD_SIZE, 1, fp) == 1;
}

void print_file(const char *filename) {
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        printf("n/a\n");
        return;
    }

    Record rec;
    int ok = 0;
    while (fread(&rec, RECORD_SIZE, 1, fp) == 1) {
        printf("%d %d %d %d %d %d %d %d\n", rec.year, rec.month, rec.day, rec.hour, rec.minute, rec.second,
               rec.status, rec.code);
        ok = 1;
    }

    if (!ok) printf("n/a\n");

    fclose(fp);
}

void sort_file(const char *filename) {
    FILE *fp = fopen(filename, "rb+");
    if (!fp) {
        printf("n/a\n");
        return;
    }

    long count = get_file_record_count(fp);
    if (count == 0) {
        printf("n/a\n");
        fclose(fp);
        return;
    }

    Record r1, r2;
    for (long i = 0; i < count - 1; ++i) {
        for (long j = 0; j < count - i - 1; ++j) {
            read_record(fp, j, &r1);
            read_record(fp, j + 1, &r2);
            if (compare(r1, r2) > 0) {
                write_record(fp, j, &r2);
                write_record(fp, j + 1, &r1);
            }
        }
    }

    fclose(fp);
    print_file(filename);
}

void add_record_and_sort(const char *filename) {
    FILE *fp = fopen(filename, "ab");
    if (!fp) {
        printf("n/a\n");
        return;
    }

    Record rec;
    if (scanf("%d %d %d %d %d %d %d %d", &rec.year, &rec.month, &rec.day, &rec.hour, &rec.minute, &rec.second,
              &rec.status, &rec.code) != 8) {
        printf("n/a\n");
        fclose(fp);
        return;
    }

    fwrite(&rec, RECORD_SIZE, 1, fp);
    fclose(fp);

    sort_file(filename);
}

int main() {
    char filename[256];
    int command;

    if (scanf("%255s", filename) != 1) {
        printf("n/a\n");
        return 1;
    }

    if (scanf("%d", &command) != 1) {
        printf("n/a\n");
        return 1;
    }

    switch (command) {
        case 0:
            print_file(filename);
            break;
        case 1:
            sort_file(filename);
            break;
        case 2:
            add_record_and_sort(filename);
            break;
        default:
            printf("n/a\n");
    }

    return 0;
}
