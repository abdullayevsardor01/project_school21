#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// Kodlash: belgi -> ASCII
void encode() {
    char ch;
    while ((ch = getchar()) != EOF) {
        if (ch == '\n') break;
        if (!isprint(ch) && ch != ' ') {
            printf("n/a\n");
            return;
        }
        if (ch != ' ')
            printf("%02X ", ch);
    }
    printf("\n");
}

// Dekodlash: ASCII -> belgi
void decode() {
    int code;
    while (scanf("%x", &code) == 1) {
        if (code < 0 || code > 127) {
            printf("n/a\n");
            return;
        }
        printf("%c ", code);
    }
    printf("\n");
}

int main(int argc, char *argv[]) {
    if (argc != 2 || (argv[1][0] != '0' && argv[1][0] != '1')) {
        printf("n/a\n");
        return 0;
    }

    if (argv[1][0] == '0')
        encode();
    else
        decode();

    return 0;
}
