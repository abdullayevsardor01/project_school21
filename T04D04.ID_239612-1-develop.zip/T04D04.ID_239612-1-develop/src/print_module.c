#include <stdio.h>

// Log funksiyasi
void print_log(char *message) {
    fprintf(stderr, "[LOG]: %s\n", message);
}
