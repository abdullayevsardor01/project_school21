#include <stdio.h>

// Tub sonligini tekshiruvchi funksiya
int is_prime(int num) {
    if (num < 2) return 0;
    for (int i = 2; i < num; ++i) {
        int temp = num;
        while (temp >= i) temp -= i;
        if (temp == 0) return 0; // num % i == 0 => tub emas
    }
    return 1;
}

// Bo'linishini tekshiruvchi funksiya (ayirish bilan)
int is_divisible(int a, int b) {
    if (b == 0) return 0;
    int temp = a;
    while (temp >= b) temp -= b;
    return (temp == 0);
}

// Eng katta tub bo'luvchini topuvchi funksiya
int max_prime_factor(int n) {
    if (n < 2) return -1;
    int max = -1;
    for (int i = 2; i <= n; ++i) {
        if (is_prime(i) && is_divisible(n, i)) {
            max = i;
        }
    }
    return max;
}

int main() {
    int n;
    if (scanf("%d", &n) != 1 || n < 2) {
        printf("n/a\n");
        return 0;
    }

    int result = max_prime_factor(n);
    if (result == -1)
        printf("n/a\n");
    else
        printf("%d\n", result);

    return 0;
}
