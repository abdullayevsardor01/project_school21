#include <stdio.h>

// Binary search funksiyasi (rekursiv)
int binary_search(int arr[], int left, int right, int key) {
    if (left > right) return 0;

    int mid = left + (right - left) / 2;

    if (arr[mid] == key)
        return 1;
    else if (arr[mid] > key)
        return binary_search(arr, left, mid - 1, key);
    else
        return binary_search(arr, mid + 1, right, key);
}

int main() {
    int n, k;
    if (scanf("%d %d", &n, &k) != 2 || n <= 0) {
        printf("n/a\n");
        return 0;
    }

    int arr[n];
    for (int i = 0; i < n; ++i) {
        if (scanf("%d", &arr[i]) != 1) {
            printf("n/a\n");
            return 0;
        }
    }

    int result = binary_search(arr, 0, n - 1, k);
    printf("%d\n", result);

    return 0;
}
