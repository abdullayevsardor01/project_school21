#include "my_string.h"

// String uzunligini hisoblash
int my_strlen(const char *str) {
    int length = 0;
    while (str[length] != '\0') {
        length++;
    }
    return length;
}

// String nusxasini olish
void my_strcpy(char *dest, const char *src) {
    int i = 0;
    while ((dest[i] = src[i]) != '\0') {
        i++;
    }
}

// Stringni birlashtirish (concat)
void my_strcat(char *dest, const char *src) {
    int dest_len = my_strlen(dest);
    int i = 0;
    while ((dest[dest_len + i] = src[i]) != '\0') {
        i++;
    }
}
