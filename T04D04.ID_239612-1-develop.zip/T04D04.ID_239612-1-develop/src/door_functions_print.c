#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define WIDTH 42     // absissa o'qi (x) bo'yicha bo'linmalar soni
#define HEIGHT 21    // ordinata o'qi (y) bo'yicha bo'linmalar soni
#define PI 3.14159265358979323846

// Jadval uchun qiymatlarni hisoblaydigan funksiyalar
double verzyera_anyezi(double x) {
    if (x == 0.0) return -1.0;
    return 1.0 / (1.0 + x * x);
}

double lemniscate_bernoulli(double x) {
    double under_sqrt = 1 - x * x * x * x;
    if (under_sqrt < 0.0) return -1.0;
    return sqrt(under_sqrt);
}

double hyperbola(double x) {
    if (x == 0.0) return -1.0;
    return 1.0 / x;
}

// Ko'rsatilgan funksiya bo'yicha grafikni chizish
void draw_graph(double (*func)(double), const char* name) {
    double xmin = -PI;
    double xmax = PI;
    double dx = (xmax - xmin) / (WIDTH - 1);

    double y_vals[WIDTH];
    double ymin = 1e9, ymax = -1e9;

    // 1. Funksiya qiymatlarini hisoblash
    for (int i = 0; i < WIDTH; ++i) {
        double x = xmin + i * dx;
        double y = func(x);
        y_vals[i] = y;

        if (y != -1.0) {
            if (y < ymin) ymin = y;
            if (y > ymax) ymax = y;
        }
    }

    // Agar qiymatlar topilmasa, grafik chizilmaydi
    if (ymin > ymax) {
        printf("%s funksiyasi uchun grafik chizilmadi (aniqlanmagan qiymatlar).\n\n", name);
        return;
    }

    // 2. Ordinata o'qidagi darajalar bo'yicha grafikni chizish
    for (int row = 0; row < HEIGHT; ++row) {
        double y_level = ymax - row * (ymax - ymin) / (HEIGHT - 1);

        for (int col = 0; col < WIDTH; ++col) {
            if (y_vals[col] == -1.0) {
                printf(" ");
                continue;
            }
            if (fabs(y_vals[col] - y_level) < (ymax - ymin) / (HEIGHT * 2)) {
                printf("*");
            } else {
                printf(" ");
            }
        }
        printf("\n");
    }

    // 3. Oxirida grafik nomi
    printf("-- %s\n\n", name);
}

int main() {
    draw_graph(verzyera_anyezi, "Verzyera Anyezi");
    draw_graph(lemniscate_bernoulli, "Lemniskata Bernulli");
    draw_graph(hyperbola, "Kvadratik Giperbola");

    return 0;
}
