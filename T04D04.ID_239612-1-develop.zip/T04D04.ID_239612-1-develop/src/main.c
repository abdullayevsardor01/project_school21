#include <stdio.h>
#include "my_string.h"

int main() {
    char buffer[100] = "Salom, ";
    char name[] = "Dunyo!";
    
    printf("Length: %d\n", my_strlen(name));
    my_strcat(buffer, name);
    printf("Concatenated: %s\n", buffer);
    
    char copy[100];
    my_strcpy(copy, buffer);
    printf("Copied: %s\n", copy);

    return 0;
}
