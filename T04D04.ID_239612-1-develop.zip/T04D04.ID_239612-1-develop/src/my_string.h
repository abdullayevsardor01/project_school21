#ifndef MY_STRING_H
#define MY_STRING_H

int my_strlen(const char *str);
void my_strcpy(char *dest, const char *src);
void my_strcat(char *dest, const char *src);

#endif
