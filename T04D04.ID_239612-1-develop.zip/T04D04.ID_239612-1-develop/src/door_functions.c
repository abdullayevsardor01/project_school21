#include <stdio.h>
#include <math.h>

#define PI 3.14159265358979323846
#define STEPS 42

int main() {
    double start = -PI;
    double end = PI;
    double step = (end - start) / (STEPS - 1);

    for (int i = 0; i < STEPS; i++) {
        double x = start + i * step;
        double f1 = 1.0 / (1.0 + x * x); // Verzyera Anyezi
        double f2;
        double f3;

        // f2: Lemniskata Bernulli
        if (fabs(x) <= 1.0)
            f2 = sqrt(1.0 - x * x);
        else
            f2 = NAN;

        // f3: Kvadratik giperbola
        if (x != 0.0)
            f3 = 1.0 / x;
        else
            f3 = NAN;

        // Chiqarish
        printf("%.7f|%.7f|", x, f1);
        if (!isnan(f2))
            printf("%.7f|", f2);
        else
            printf("-|");
        if (!isnan(f3))
            printf("%.7f\n", f3);
        else
            printf("-\n");
    }

    return 0;
}
