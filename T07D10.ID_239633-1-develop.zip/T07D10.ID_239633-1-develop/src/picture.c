#include <stdio.h>

#define N 15
#define M 13

void transform(int *buf, int **matr, int n, int m);
void make_picture(int **picture, int n, int m);
void reset_picture(int **picture, int n, int m);
void print_picture(int **picture, int n, int m);

int main() {
    int picture_data[N][M];
    int *picture[N];
    transform(&picture_data[0][0], picture, N, M);

    make_picture(picture, N, M);
    print_picture(picture, N, M);
    return 0;
}

void transform(int *buf, int **matr, int n, int m) {
    for (int i = 0; i < n; i++) {
        matr[i] = buf + i * m;
    }
}

void reset_picture(int **picture, int n, int m) {
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++) picture[i][j] = 0;
}

void make_picture(int **picture, int n, int m) {
    int data[N][M] = {{1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, {1, 0, 0, 0, 0, 0, 1, 0, 6, 6, 6, 6, 1},
                      {1, 0, 0, 3, 3, 0, 1, 0, 0, 6, 6, 6, 1}, {1, 0, 3, 3, 3, 3, 1, 0, 0, 6, 6, 6, 1},
                      {1, 0, 3, 3, 3, 3, 1, 0, 6, 0, 0, 6, 1}, {1, 0, 0, 3, 3, 0, 1, 0, 0, 0, 0, 0, 1},
                      {1, 0, 0, 7, 7, 0, 1, 0, 0, 0, 0, 0, 1}, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
                      {1, 0, 0, 7, 7, 0, 1, 0, 0, 0, 0, 0, 1}, {1, 0, 0, 7, 7, 0, 1, 0, 0, 0, 0, 0, 1},
                      {1, 0, 7, 7, 7, 7, 1, 0, 0, 0, 0, 0, 1}, {1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1},
                      {1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1}, {1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1},
                      {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}};

    // Copying data[] into picture[] (so we don't need to re-code pattern)
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++) picture[i][j] = data[i][j];
}

void print_picture(int **picture, int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            char ch;
            switch (picture[i][j]) {
                case 0:
                    ch = ' ';
                    break;
                case 1:
                    ch = '#';
                    break;
                case 3:
                    ch = '^';
                    break;
                case 6:
                    ch = '~';
                    break;
                case 7:
                    ch = '@';
                    break;
                default:
                    ch = '?';
                    break;
            }
            printf("%c", ch);
        }
        if (i != n - 1) printf("\n");  // oxirgi qatordan keyin yangi satr bo‘lmasin
    }
}
