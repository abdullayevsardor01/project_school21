#include <stdio.h>
#include <stdlib.h>

#define MAX 100

void print_matrix_static(int matrix[MAX][MAX], int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d", matrix[i][j]);
            if (j < cols - 1) printf(" ");
        }
        if (i < rows - 1) printf("\n");
    }
}

void print_matrix_dynamic1(int *matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d", matrix[i * cols + j]);
            if (j < cols - 1) printf(" ");
        }
        if (i < rows - 1) printf("\n");
    }
}

void print_matrix_dynamic2(int **matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d", matrix[i][j]);
            if (j < cols - 1) printf(" ");
        }
        if (i < rows - 1) printf("\n");
    }
}

int main() {
    int rows, cols, method;

    if (scanf("%d %d", &rows, &cols) != 2 || rows <= 0 || cols <= 0) {
        printf("n/a");
        return 1;
    }

    printf("Xotira ajratish usulini tanlang:\n");
    printf("1. Statik\n2. Dinamik 1-usul (1 malloc)\n");
    printf("3. Dinamik 2-usul (row + malloc)\n");
    printf("4. Dinamik 3-usul (shifting pointer)\n");
    printf("Tanlov: ");

    if (scanf("%d", &method) != 1 || method < 1 || method > 4) {
        printf("n/a");
        return 1;
    }

    if (method == 1) {
        if (rows > MAX || cols > MAX) {
            printf("n/a");
            return 1;
        }
        int matrix[MAX][MAX];
        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                if (scanf("%d", &matrix[i][j]) != 1) {
                    printf("n/a");
                    return 1;
                }
        print_matrix_static(matrix, rows, cols);
    }

    else if (method == 2) {
        int *matrix = malloc(rows * cols * sizeof(int));
        if (!matrix) {
            printf("n/a");
            return 1;
        }

        for (int i = 0; i < rows * cols; i++)
            if (scanf("%d", &matrix[i]) != 1) {
                printf("n/a");
                free(matrix);
                return 1;
            }

        print_matrix_dynamic1(matrix, rows, cols);
        free(matrix);
    }

    else if (method == 3) {
        int **matrix = malloc(rows * sizeof(int *));
        if (!matrix) {
            printf("n/a");
            return 1;
        }

        for (int i = 0; i < rows; i++) {
            matrix[i] = malloc(cols * sizeof(int));
            if (!matrix[i]) {
                for (int k = 0; k < i; k++) free(matrix[k]);
                free(matrix);
                printf("n/a");
                return 1;
            }
        }

        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                if (scanf("%d", &matrix[i][j]) != 1) {
                    for (int k = 0; k < rows; k++) free(matrix[k]);
                    free(matrix);
                    printf("n/a");
                    return 1;
                }

        print_matrix_dynamic2(matrix, rows, cols);
        for (int i = 0; i < rows; i++) free(matrix[i]);
        free(matrix);
    }

    else if (method == 4) {
        int **matrix = malloc(rows * sizeof(int *));
        int *data = malloc(rows * cols * sizeof(int));
        if (!matrix || !data) {
            free(matrix);
            free(data);
            printf("n/a");
            return 1;
        }

        for (int i = 0; i < rows; i++) matrix[i] = data + i * cols;

        for (int i = 0; i < rows; i++)
            for (int j = 0; j < cols; j++)
                if (scanf("%d", &matrix[i][j]) != 1) {
                    free(data);
                    free(matrix);
                    printf("n/a");
                    return 1;
                }

        print_matrix_dynamic2(matrix, rows, cols);
        free(data);
        free(matrix);
    }

    return 0;
}
