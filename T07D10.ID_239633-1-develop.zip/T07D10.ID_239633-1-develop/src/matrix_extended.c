#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 100

void free_all(int **matrix, int method, int *data) {
    if (method == 2 || method == 3) {
        free(matrix);
    } else if (method == 4) {
        free(data);
        free(matrix);
    }
}

int main() {
    int method, rows, cols;
    if (scanf("%d", &method) != 1 || method < 1 || method > 4) {
        printf("n/a");
        return 1;
    }
    if (scanf("%d %d", &rows, &cols) != 2 || rows <= 0 || cols <= 0 || rows > MAX_SIZE || cols > MAX_SIZE) {
        printf("n/a");
        return 1;
    }

    int **matrix = NULL;
    int *data = NULL;
    if (method == 1) {
        static int static_matrix[MAX_SIZE][MAX_SIZE];
        matrix = (int **)malloc(rows * sizeof(int *));
        if (!matrix) {
            printf("n/a");
            return 1;
        }
        for (int i = 0; i < rows; ++i) {
            matrix[i] = static_matrix[i];
        }
    } else if (method == 2) {
        matrix = (int **)malloc(rows * sizeof(int *));
        if (!matrix) {
            printf("n/a");
            return 1;
        }
        for (int i = 0; i < rows; ++i) {
            matrix[i] = (int *)malloc(cols * sizeof(int));
            if (!matrix[i]) {
                printf("n/a");
                return 1;
            }
        }
    } else if (method == 3) {
        matrix = (int **)malloc(rows * sizeof(int *));
        data = (int *)malloc(rows * cols * sizeof(int));
        if (!matrix || !data) {
            printf("n/a");
            return 1;
        }
        for (int i = 0; i < rows; ++i) {
            matrix[i] = data + i * cols;
        }
    } else if (method == 4) {
        data = (int *)malloc(rows * cols * sizeof(int));
        matrix = (int **)malloc(rows * sizeof(int *));
        if (!data || !matrix) {
            printf("n/a");
            return 1;
        }
        for (int i = 0; i < rows; ++i) {
            matrix[i] = data + i * cols;
        }
    }

    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            if (scanf("%d", &matrix[i][j]) != 1) {
                printf("n/a");
                free_all(matrix, method, data);
                return 1;
            }
        }
    }

    // Matrix print
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            printf("%d", matrix[i][j]);
            if (j < cols - 1) printf(" ");
        }
        if (i < rows - 1) printf("\n");
    }

    // Max in rows
    int row_max[rows];
    for (int i = 0; i < rows; ++i) {
        int max = matrix[i][0];
        for (int j = 1; j < cols; ++j) {
            if (matrix[i][j] > max) max = matrix[i][j];
        }
        row_max[i] = max;
    }

    printf("\n");
    for (int i = 0; i < rows; ++i) {
        printf("%d", row_max[i]);
        if (i < rows - 1) printf(" ");
    }

    // Min in columns
    int col_min[cols];
    for (int j = 0; j < cols; ++j) {
        int min = matrix[0][j];
        for (int i = 1; i < rows; ++i) {
            if (matrix[i][j] < min) min = matrix[i][j];
        }
        col_min[j] = min;
    }

    printf("\n");
    for (int j = 0; j < cols; ++j) {
        printf("%d", col_min[j]);
        if (j < cols - 1) printf(" ");
    }

    free_all(matrix, method, data);
    return 0;
}
