#include <stdio.h>
#include <stdlib.h>

int input(int **matrix, int *n, int *m) {
    if (scanf("%d %d", n, m) != 2 || *n <= 0 || *m <= 0) return 0;

    for (int i = 0; i < *n; i++)
        for (int j = 0; j < *m; j++)
            if (scanf("%d", &matrix[i][j]) != 1) return 0;

    return 1;
}

void output(int **matrix, int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            printf("%d", matrix[i][j]);
            if (j < m - 1) printf(" ");
        }
        printf("\n");
    }
}

int sum(int **a, int n1, int m1, int **b, int n2, int m2, int **res, int *n_res, int *m_res) {
    if (n1 != n2 || m1 != m2) return 0;

    *n_res = n1;
    *m_res = m1;

    for (int i = 0; i < n1; i++)
        for (int j = 0; j < m1; j++) res[i][j] = a[i][j] + b[i][j];

    return 1;
}

int transpose(int **matrix, int n, int m) {
    int **res = malloc(m * sizeof(int *));
    if (!res) return 0;
    for (int i = 0; i < m; i++) {
        res[i] = malloc(n * sizeof(int));
        if (!res[i]) return 0;
    }

    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++) res[j][i] = matrix[i][j];

    output(res, m, n);

    for (int i = 0; i < m; i++) free(res[i]);
    free(res);
    return 1;
}

int mul(int **a, int n1, int m1, int **b, int n2, int m2, int **res, int *n_res, int *m_res) {
    if (m1 != n2) return 0;

    *n_res = n1;
    *m_res = m2;

    for (int i = 0; i < n1; i++)
        for (int j = 0; j < m2; j++) {
            res[i][j] = 0;
            for (int k = 0; k < m1; k++) res[i][j] += a[i][k] * b[k][j];
        }

    return 1;
}

// Matritsa ajratish
int **alloc_matrix(int rows, int cols) {
    int **matrix = malloc(rows * sizeof(int *));
    if (!matrix) return NULL;
    for (int i = 0; i < rows; i++) {
        matrix[i] = malloc(cols * sizeof(int));
        if (!matrix[i]) return NULL;
    }
    return matrix;
}

// Xotirani tozalash
void free_matrix(int **matrix, int rows) {
    for (int i = 0; i < rows; i++) free(matrix[i]);
    free(matrix);
}

int main() {
    int op;
    if (scanf("%d", &op) != 1 || op < 1 || op > 3) {
        printf("n/a\n");
        return 1;
    }

    int n1, m1, n2, m2, n_res, m_res;
    int **a = alloc_matrix(100, 100);  // maksimal o‘lchamlar, agar bilmasak
    int **b = alloc_matrix(100, 100);
    int **res = alloc_matrix(100, 100);
    if (!a || !b || !res) {
        printf("n/a\n");
        return 1;
    }

    if (op == 1) {  // Qo‘shish
        if (!input(a, &n1, &m1) || !input(b, &n2, &m2) || !sum(a, n1, m1, b, n2, m2, res, &n_res, &m_res)) {
            printf("n/a\n");
        } else {
            output(res, n_res, m_res);
        }
    } else if (op == 2) {  // Ko‘paytirish
        if (!input(a, &n1, &m1) || !input(b, &n2, &m2) || !mul(a, n1, m1, b, n2, m2, res, &n_res, &m_res)) {
            printf("n/a\n");
        } else {
            output(res, n_res, m_res);
        }
    } else if (op == 3) {  // Transponlash
        if (!input(a, &n1, &m1) || !transpose(a, n1, m1)) {
            printf("n/a\n");
        }
    }

    free_matrix(a, 100);
    free_matrix(b, 100);
    free_matrix(res, 100);
    return 0;
}
