#include <stdio.h>

int main() {
    int A[4][4] = {{87, 46, 57, 29}, {129, 156, 122, 141}, {143, 127, 107, 116}, {69, 78, 112, 101}};

    int R[4][4] = {0};

    // A * A
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            for (int k = 0; k < 4; k++) {
                R[i][j] += A[i][k] * A[k][j];
            }
        }
    }

    // Faylga yozish
    FILE *f = fopen("key10.txt", "w");
    if (!f) {
        printf("Fayl ochilmadi.\n");
        return 1;
    }

    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            fprintf(f, "%d", R[i][j]);
            if (j < 3) fprintf(f, " ");
        }
        fprintf(f, "\n");
    }

    fclose(f);
    printf("✅ Natija src/key10.txt faylga saqlandi.\n");

    return 0;
}
