#include <stdio.h>
#include <stdlib.h>

// Global o‘lcham o‘zgaruvchisi
int M;

// Satrdagi minimum qiymatni topuvchi funksiya
int row_min(int *row) {
    int min = row[0];
    for (int i = 1; i < M; i++) {
        if (row[i] < min) min = row[i];
    }
    return min;
}

// Qsort uchun solishtiruvchi funksiya
int compare_rows(const void *a, const void *b) {
    int *rowA = *(int **)a;
    int *rowB = *(int **)b;
    return row_min(rowA) - row_min(rowB);
}

int main() {
    int N;

    // N va M ni o'qish
    if (scanf("%d %d", &N, &M) != 2 || N <= 0 || M <= 0) {
        printf("n/a\n");
        return 1;
    }

    // Matritsani ajratish (2D dinamik xotira)
    int **matrix = malloc(N * sizeof(int *));
    if (!matrix) {
        printf("n/a\n");
        return 1;
    }

    for (int i = 0; i < N; i++) {
        matrix[i] = malloc(M * sizeof(int));
        if (!matrix[i]) {
            printf("n/a\n");
            // Oldingi ajratilgan satrlarni tozalash
            for (int k = 0; k < i; k++) free(matrix[k]);
            free(matrix);
            return 1;
        }

        for (int j = 0; j < M; j++) {
            if (scanf("%d", &matrix[i][j]) != 1) {
                printf("n/a\n");
                // Xotirani tozalash
                for (int k = 0; k <= i; k++) free(matrix[k]);
                free(matrix);
                return 1;
            }
        }
    }

    // Saralash
    qsort(matrix, N, sizeof(int *), compare_rows);

    // Natijani chiqarish
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            printf("%d", matrix[i][j]);
            if (j < M - 1) printf(" ");
        }
        printf("\n");
    }

    // Xotirani tozalash
    for (int i = 0; i < N; i++) free(matrix[i]);
    free(matrix);

    return 0;
}
