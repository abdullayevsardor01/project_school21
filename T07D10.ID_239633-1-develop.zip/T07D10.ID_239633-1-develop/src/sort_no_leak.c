#include <stdio.h>
#include <stdlib.h>

int main() {
    int n;
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("n/a");
        return 1;
    }

    int *arr = (int *)calloc(n, sizeof(int));
    if (!arr) {
        printf("n/a");
        return 1;
    }

    for (int i = 0; i < n; i++) {
        if (scanf("%d", &arr[i]) != 1) {
            printf("n/a");
            free(arr);  // xato bo‘lsa ham xotirani tozalaymiz
            return 1;
        }
    }

    // Oddiy Bubble sort
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int t = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = t;
            }
        }
    }

    for (int i = 0; i < n; i++) {
        if (i > 0) printf(" ");
        printf("%d", arr[i]);
    }

    // ❗❗❗ MUHIM: Xotirani tozalash
    free(arr);

    return 0;
}
