#include <ctype.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "logger.h"

#define MAX_PATH 256
#define MAX_LINE 1024

char current_file[MAX_PATH] = "";

void read_file(const char *filename, FILE *log) {
    char full_path[MAX_PATH] = "build/";
    strncat(full_path, filename, MAX_PATH - strlen(full_path) - 1);

    FILE *fp = fopen(full_path, "r");
    if (fp == NULL) {
        printf("n/a\n\n");
        logcat(log, "File open failed", ERROR);
        return;
    }

    char log_msg[1024];
    snprintf(log_msg, sizeof(log_msg), "File '%s' opened", filename);
    logcat(log, log_msg, INFO);

    char line[MAX_LINE];
    int has_content = 0;

    while (fgets(line, sizeof(line), fp)) {
        printf("%s", line);
        has_content = 1;
    }

    if (!has_content) {
        printf("n/a\n");
    }

    printf("\n");
    fclose(fp);
}

void write_to_file(const char *filename, const char *text, FILE *log) {
    if (strlen(filename) == 0) {
        printf("n/a\n\n");
        logcat(log, "Write failed: no file loaded", ERROR);
        return;
    }

    char full_path[MAX_PATH] = "build/";
    strncat(full_path, filename, MAX_PATH - strlen(full_path) - 1);

    FILE *fp = fopen(full_path, "a");
    if (fp == NULL) {
        printf("n/a\n\n");
        logcat(log, "Write failed: file access error", ERROR);
        return;
    }

    fprintf(fp, "%s\n", text);
    fclose(fp);

    char log_msg[1024];
    snprintf(log_msg, sizeof(log_msg), "Wrote to '%s': %s", filename, text);
    logcat(log, log_msg, INFO);

    read_file(filename, log);
}

char shift_char(char c, int shift) {
    if (isalpha(c)) {
        char base = islower(c) ? 'a' : 'A';
        return (char)((c - base + shift) % 26 + base);
    }
    return c;
}

void encrypt_caesar(const char *dirpath, int shift, FILE *log) {
    DIR *dir = opendir(dirpath);
    if (!dir) {
        printf("n/a\n\n");
        logcat(log, "Directory open failed (Caesar)", ERROR);
        return;
    }

    struct dirent *entry;
    char filepath[512];

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type != DT_REG) continue;
        const char *name = entry->d_name;

        size_t written = snprintf(filepath, sizeof(filepath), "%s/%s", dirpath, name);
        if (written >= sizeof(filepath)) continue;

        if (strstr(name, ".c")) {
            FILE *fp = fopen(filepath, "r+");
            if (!fp) continue;

            fseek(fp, 0, SEEK_END);
            long size = ftell(fp);
            fseek(fp, 0, SEEK_SET);

            char *buffer = malloc(size + 1);
            if (!buffer) {
                fclose(fp);
                continue;
            }

            fread(buffer, 1, size, fp);
            buffer[size] = '\0';

            for (long i = 0; i < size; i++) {
                buffer[i] = shift_char(buffer[i], shift);
            }

            freopen(filepath, "w", fp);
            fwrite(buffer, 1, size, fp);
            fclose(fp);
            free(buffer);

            char log_msg[1024];
            snprintf(log_msg, sizeof(log_msg), "Caesar encrypted '%s' with shift %d", filepath, shift);
            logcat(log, log_msg, DEBUG);
        } else if (strstr(name, ".h")) {
            FILE *fp = fopen(filepath, "w");
            if (fp) fclose(fp);

            char log_msg[1024];
            snprintf(log_msg, sizeof(log_msg), "Cleared header file: %s", filepath);
            logcat(log, log_msg, INFO);
        }
    }

    closedir(dir);
    printf("\n");
}

void mock_des_encrypt(const char *filepath, const char *key, FILE *log) {
    FILE *fp = fopen(filepath, "r+");
    if (!fp) return;

    fseek(fp, 0, SEEK_END);
    long size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    char *buffer = malloc(size + 1);
    if (!buffer) {
        fclose(fp);
        return;
    }

    fread(buffer, 1, size, fp);
    buffer[size] = '\0';

    size_t keylen = strlen(key);
    for (long i = 0; i < size; i++) {
        buffer[i] ^= key[i % keylen];
    }

    freopen(filepath, "w", fp);
    fwrite(buffer, 1, size, fp);
    fclose(fp);
    free(buffer);

    char log_msg[1024];
    snprintf(log_msg, sizeof(log_msg), "DES encrypted '%s' with key '%s'", filepath, key);
    logcat(log, log_msg, DEBUG);
}

int main() {
    FILE *log = log_init("build/log.txt");

    int choice;
    char path[MAX_PATH];
    char input[MAX_LINE];

    while (1) {
        if (scanf("%d", &choice) != 1) break;

        if (choice == -1)
            break;

        else if (choice == 1) {
            scanf("%s", path);
            strncpy(current_file, path, MAX_PATH - 1);
            current_file[MAX_PATH - 1] = '\0';
            read_file(current_file, log);
        } else if (choice == 2) {
            getchar();
            if (strlen(current_file) == 0) {
                printf("n/a\n\n");
                continue;
            }
            fgets(input, sizeof(input), stdin);
            input[strcspn(input, "\n")] = '\0';
            write_to_file(current_file, input, log);
        } else if (choice == 3) {
            char dir[MAX_PATH];
            int shift;
            scanf("%s", dir);
            scanf("%d", &shift);
            encrypt_caesar(dir, shift, log);
        } else if (choice == 4) {
            char dir[MAX_PATH], key[MAX_PATH];
            scanf("%s", dir);
            scanf("%s", key);

            DIR *dp = opendir(dir);
            if (!dp) {
                printf("n/a\n\n");
                logcat(log, "Directory open failed (DES)", ERROR);
                continue;
            }

            struct dirent *entry;
            char filepath[512];

            while ((entry = readdir(dp)) != NULL) {
                if (entry->d_type != DT_REG) continue;
                const char *name = entry->d_name;

                size_t written = snprintf(filepath, sizeof(filepath), "%s/%s", dir, name);
                if (written >= sizeof(filepath)) continue;

                if (strstr(name, ".c")) {
                    mock_des_encrypt(filepath, key, log);
                } else if (strstr(name, ".h")) {
                    FILE *fp = fopen(filepath, "w");
                    if (fp) fclose(fp);

                    char log_msg[1024];
                    snprintf(log_msg, sizeof(log_msg), "Cleared header file: %s", filepath);
                    logcat(log, log_msg, INFO);
                }
            }

            closedir(dp);
            printf("\n");
        }
    }

    log_close(log);
    return 0;
}
