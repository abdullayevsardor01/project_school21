#include "logger.h"

#include <time.h>

FILE* log_init(const char* filename) { return fopen(filename, "a"); }

const char* level_to_string(log_level level) {
    switch (level) {
        case DEBUG:
            return "DEBUG";
        case INFO:
            return "INFO";
        case WARNING:
            return "WARNING";
        case ERROR:
            return "ERROR";
        default:
            return "UNKNOWN";
    }
}

int logcat(FILE* log_file, const char* message, log_level level) {
    if (!log_file) return -1;

    time_t now = time(NULL);
    struct tm* t = localtime(&now);
    char time_str[20];
    strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", t);

    fprintf(log_file, "[%s] %s: %s\n", level_to_string(level), time_str, message);
    fflush(log_file);
    return 0;
}

int log_close(FILE* log_file) {
    if (!log_file) return -1;
    return fclose(log_file);
}
