#ifndef STATUS_EVENT_H
#define STATUS_EVENT_H

typedef struct {
    int event_id;
    int module_id;
    int status;
    char date[11];
    char time[9];
} StatusEvent;

int add_status_event(StatusEvent e);
int show_all_status_events();

#endif
