#ifndef LEVEL_H
#define LEVEL_H

typedef struct {
    int level;
    int num_cells;
    int protection_flag;
} Level;

int update_level_protection(int target_level, int flag);
int show_all_levels();

// Qo‘shiladi:
void show_all_levels_ui();
void set_level_protection_flag();

#endif
