#include "status_event.h"  // struct StatusEvent shu faylda mavjud

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define STATUS_DB_PATH "../materials/master_status_events.db"

// Status hodisasini faylga yozish
int add_status_event(StatusEvent e) {
    FILE *file = fopen(STATUS_DB_PATH, "ab");
    if (!file) {
        printf("❌ Status faylini ochib bo‘lmadi\n");
        return -1;
    }
    fwrite(&e, sizeof(StatusEvent), 1, file);
    fclose(file);
    return 0;
}

// Barcha status hodisalarini ko'rsatish
int show_all_status_events() {
    FILE *file = fopen(STATUS_DB_PATH, "rb");
    if (!file) {
        printf("❌ Status faylini ochib bo‘lmadi\n");
        return -1;
    }
    StatusEvent e;
    printf("ID\tModule ID\tStatus\tDate\t\tTime\n");
    printf("-----------------------------------------------------\n");
    while (fread(&e, sizeof(StatusEvent), 1, file)) {
        printf("%d\t%d\t\t%d\t%s\t%s\n", e.event_id, e.module_id, e.status, e.date, e.time);
    }
    fclose(file);
    return 0;
}
