#include "level.h"  // Boshqa fayllar bilan integratsiya uchun kerak

#include <stdio.h>
#include <stdlib.h>

#define LEVELS_DB_PATH "../materials/master_levels.db"

// Darajani yangilash (faqat protection_flag uchun)
int update_level_protection(int target_level, int flag) {
    FILE *file = fopen(LEVELS_DB_PATH, "r+b");  // o'qish va yozish rejimi
    if (!file) return -1;

    Level l;
    while (fread(&l, sizeof(Level), 1, file)) {
        if (l.level == target_level) {
            l.protection_flag = flag;
            fseek(file, -sizeof(Level), SEEK_CUR);
            fwrite(&l, sizeof(Level), 1, file);
            fclose(file);
            return 1;
        }
    }
    fclose(file);
    return 0;  // topilmadi
}

// Barcha darajalarni ko'rsatish
int show_all_levels() {
    FILE *file = fopen(LEVELS_DB_PATH, "rb");
    if (!file) return -1;
    Level l;
    printf("Level\tCells\tProtection\n");
    while (fread(&l, sizeof(Level), 1, file)) {
        printf("%d\t%d\t%d\n", l.level, l.num_cells, l.protection_flag);
    }
    fclose(file);
    return 0;
}

// 🌟 UI ko‘rinishda darajalarni ko‘rsatish
void show_all_levels_ui() {
    printf("=====================================\n");
    printf("       DARAJALAR RO‘YXATI (LEVELS)   \n");
    printf("=====================================\n");
    show_all_levels();  // mavjud funksiyani chaqiradi
    printf("=====================================\n");
}

// 🌟 Foydalanuvchidan daraja raqamini olib, himoyalash
void set_level_protection_flag() {
    int level;
    printf("Himoyalanadigan daraja raqamini kiriting: ");
    scanf("%d", &level);

    if (update_level_protection(level, 1)) {
        printf("✅ %d-daraja himoyalandi (protection_flag = 1)\n", level);
    } else {
        printf("❌ Xatolik: daraja topilmadi yoki yozib bo‘lmadi.\n");
    }
}
