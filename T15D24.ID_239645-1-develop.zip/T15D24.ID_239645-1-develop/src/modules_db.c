#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "level.h"
#include "shared.h"
#include "status_event.h"

// Funksiya prototiplari
void choose_operation_menu();
void choose_table_menu();
void show_modules_with_last_status_1();
void move_module_to_level_cell();
void set_level_protection_flag();
void show_all_levels_ui();

void choose_operation_menu() {
    printf("\nPlease choose one operation: (Iltimos, amal tanlang)\n");
    printf("  1. SELECT (Ma'lumotlarni ko'rish)\n");
    printf("  2. INSERT (Yangi yozuv qo'shish)\n");
    printf("  3. UPDATE (Yozuvni yangilash)\n");
    printf("  4. DELETE (Yozuvni o'chirish)\n");
    printf("  5. Get all active additional modules (statusi 1 bo'lgan modullarni ko'rsatish)\n");
    printf("  6. Delete modules by ids (ID bo'yicha modullarni o'chirish)\n");
    printf("  7. Set protected mode for module by id (Modulni himoyalash - tayyor emas)\n");
    printf("  8. Move module by id to specified memory level and cell (Modulni boshqa joyga ko'chirish)\n");
    printf("  9. Set protection flag of the specified memory level (Darajani himoyalash)\n");
    printf("  0. Exit (Chiqish)\n> ");
}

void choose_table_menu() {
    printf("\nPlease choose a table: (Iltimos, jadvalni tanlang)\n");
    printf("  1. Modules (Modullar)\n");
    printf("  2. Levels (Darajalar)\n");
    printf("  3. Status events (Status holatlari)\n> ");
}

int main() {
    int op, table, id, n;
    Module m;

    while (1) {
        choose_operation_menu();
        if (scanf("%d", &op) != 1) {
            printf("Noto'g'ri kiritildi. Qayta urinib ko'ring.\n");
            while (getchar() != '\n');
            continue;
        }
        getchar();  // '\n' ni yutish

        switch (op) {
            case 1:  // SELECT
                choose_table_menu();
                scanf("%d", &table);
                getchar();
                if (table == 1) {
                    printf("> (ixtiyoriy) Yozuvlar sonini kiriting yoki 0 - hammasini ko'rsatish: ");
                    scanf("%d", &n);
                    getchar();
                    select_all_modules();  // n parametr hali ishlatilmaydi
                } else if (table == 2) {
                    show_all_levels_ui();
                } else if (table == 3) {
                    show_all_status_events();
                } else {
                    printf("Noto'g'ri jadval tanlandi.\n");
                }
                break;

            case 2:  // INSERT
                choose_table_menu();
                scanf("%d", &table);
                getchar();
                if (table == 1) {
                    printf("> ID: ");
                    scanf("%d", &m.id);
                    getchar();
                    printf("> Name (Nomi): ");
                    fgets(m.name, 30, stdin);
                    m.name[strcspn(m.name, "\n")] = 0;
                    printf("> Level (Daraja): ");
                    scanf("%d", &m.memory_level);
                    printf("> Cell (Xujayra): ");
                    scanf("%d", &m.cell);
                    m.deleted = 0;
                    insert_module(m);
                } else {
                    printf("Faqat Modules jadvali uchun qo'shish amalga oshirilmoqda.\n");
                }
                break;

            case 3:  // UPDATE
                printf("> Module ID to update (Yangilash uchun modul ID): ");
                scanf("%d", &id);
                getchar();
                printf("> New name (Yangi nom): ");
                fgets(m.name, 30, stdin);
                m.name[strcspn(m.name, "\n")] = 0;
                printf("> New level (Yangi daraja): ");
                scanf("%d", &m.memory_level);
                printf("> New cell (Yangi xujayra): ");
                scanf("%d", &m.cell);
                m.id = id;
                m.deleted = 0;
                update_module(id, m);
                break;

            case 4:  // DELETE
                printf("> Module ID to delete (O'chirish uchun modul ID): ");
                scanf("%d", &id);
                delete_module(id);
                break;

            case 5:  // STATUS = 1 bo‘lgan modullar
                show_modules_with_last_status_1();
                break;

            case 6:  // Bir nechta ID bo‘yicha o‘chirish
                printf("> Modul ID larini kiriting (bo'sh qator tugatadi): ");
                while (scanf("%d", &id) == 1) {
                    delete_module(id);
                }
                while (getchar() != '\n');
                printf("  Modullar o'chirilgan deb belgilandi.\n");
                break;

            case 7:  // Himoyalash (README da talab qilingan, ammo biz faqat flagni daraja bo‘yicha
                     // qo‘yayapmiz)
                printf("> (Simulyatsiya) Modul ID ni kiriting: ");
                scanf("%d", &id);
                printf(
                    "  [Himoyalash faqat daraja bo‘yicha amalga oshiriladi. Modulga bevosita himoya "
                    "o‘rnatilmaydi.]\n");
                break;

            case 8:  // Modulni boshqa joyga ko‘chirish
                move_module_to_level_cell();
                break;

            case 9:  // Darajani himoyalash
                set_level_protection_flag();
                break;

            case 0:
                printf("\n✅ Dasturdan chiqildi.\n");
                return 0;

            default:
                printf("⚠️  Noto‘g‘ri tanlov. Qayta urinib ko‘ring.\n");
        }
    }
}
