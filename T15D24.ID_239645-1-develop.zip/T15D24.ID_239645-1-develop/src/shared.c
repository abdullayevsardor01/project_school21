/* shared.c - universal DB functions for MODULES table */

#include "shared.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "status_event.h"  // StatusEvent uchun

#define MODULES_DB_PATH "../materials/master_modules.db"
#define STATUS_DB_PATH "../materials/master_status_events.db"

// INSERT - modulni faylga yozish (qo'shish)
int insert_module(Module m) {
    FILE *file = fopen(MODULES_DB_PATH, "ab");
    if (!file) return -1;
    fwrite(&m, sizeof(Module), 1, file);
    fclose(file);
    return 0;
}

// SELECT ALL - barcha modullarni ko'rsatish
int select_all_modules() {
    FILE *file = fopen(MODULES_DB_PATH, "rb");
    if (!file) return -1;
    Module m;
    printf("ID\tName\t\t\t\tLevel\tCell\tDeleted\n");
    while (fread(&m, sizeof(Module), 1, file)) {
        printf("%d\t%-30s\t%d\t%d\t%d\n", m.id, m.name, m.memory_level, m.cell, m.deleted);
    }
    fclose(file);
    return 0;
}

// UPDATE BY ID
int update_module(int id, Module updated) {
    FILE *file = fopen(MODULES_DB_PATH, "r+b");
    if (!file) return -1;
    Module m;
    while (fread(&m, sizeof(Module), 1, file)) {
        if (m.id == id) {
            fseek(file, -sizeof(Module), SEEK_CUR);
            fwrite(&updated, sizeof(Module), 1, file);
            fclose(file);
            return 0;
        }
    }
    fclose(file);
    return -2;
}

// DELETE BY ID (deleted = 1)
int delete_module(int id) {
    FILE *file = fopen(MODULES_DB_PATH, "r+b");
    if (!file) return -1;
    Module m;
    while (fread(&m, sizeof(Module), 1, file)) {
        if (m.id == id) {
            m.deleted = 1;
            fseek(file, -sizeof(Module), SEEK_CUR);
            fwrite(&m, sizeof(Module), 1, file);
            fclose(file);
            return 0;
        }
    }
    fclose(file);
    return -2;
}

// Get active modules (deleted == 0)
int get_active_modules() {
    FILE *file = fopen(MODULES_DB_PATH, "rb");
    if (!file) return -1;
    Module m;
    printf("Active Modules:\n");
    while (fread(&m, sizeof(Module), 1, file)) {
        if (m.deleted == 0) {
            printf("%d\t%-30s\tLevel: %d, Cell: %d\n", m.id, m.name, m.memory_level, m.cell);
        }
    }
    fclose(file);
    return 0;
}

// Get modules by memory level
int get_modules_by_level(int level) {
    FILE *file = fopen(MODULES_DB_PATH, "rb");
    if (!file) return -1;
    Module m;
    printf("Modules in Level %d:\n", level);
    while (fread(&m, sizeof(Module), 1, file)) {
        if (m.memory_level == level && m.deleted == 0) {
            printf("%d\t%-30s\tCell: %d\n", m.id, m.name, m.cell);
        }
    }
    fclose(file);
    return 0;
}

// ✅ YANGI: STATUS_EVENTS orqali status == 1 bo‘lgan modullarni chiqarish
void show_modules_with_last_status_1() {
    FILE *sf = fopen(STATUS_DB_PATH, "rb");
    if (!sf) {
        printf("❌ Status fayli ochilmadi\n");
        return;
    }

    int latest_status[1000];  // Maks 1000 modul
    for (int i = 0; i < 1000; i++) latest_status[i] = -1;

    StatusEvent e;
    while (fread(&e, sizeof(StatusEvent), 1, sf) == 1) {
        latest_status[e.module_id] = e.status;
    }
    fclose(sf);

    FILE *mf = fopen(MODULES_DB_PATH, "rb");
    if (!mf) {
        printf("❌ Module fayli ochilmadi\n");
        return;
    }

    Module m;
    printf("Modullar (oxirgi statusi 1):\n");
    printf("ID\tName\t\t\t\tLevel\tCell\n");
    while (fread(&m, sizeof(Module), 1, mf)) {
        if (m.deleted == 0 && latest_status[m.id] == 1) {
            printf("%d\t%-30s\t%d\t%d\n", m.id, m.name, m.memory_level, m.cell);
        }
    }
    fclose(mf);
}

// ✅ YANGI: Modulni boshqa daraja va hujayraga ko'chirish
void move_module_to_level_cell() {
    int id, new_level, new_cell;
    printf("Modul ID sini kiriting: ");
    scanf("%d", &id);
    printf("Yangi daraja (memory level): ");
    scanf("%d", &new_level);
    printf("Yangi xujayra raqami: ");
    scanf("%d", &new_cell);

    FILE *file = fopen(MODULES_DB_PATH, "r+b");
    if (!file) {
        printf("❌ Modullar fayli ochilmadi\n");
        return;
    }

    Module m;
    int found = 0;
    while (fread(&m, sizeof(Module), 1, file) == 1) {
        if (m.id == id) {
            m.memory_level = new_level;
            m.cell = new_cell;
            fseek(file, -sizeof(Module), SEEK_CUR);
            fwrite(&m, sizeof(Module), 1, file);
            found = 1;
            break;
        }
    }
    fclose(file);

    if (found)
        printf("✅ Modul %d Level %d va Cell %d ga ko‘chirildi.\n", id, new_level, new_cell);
    else
        printf("❌ Modul topilmadi\n");
}
