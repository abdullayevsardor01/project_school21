#ifndef SHARED_H
#define SHARED_H

typedef struct {
    int id;
    char name[30];
    int memory_level;
    int cell;
    int deleted;
} Module;

int insert_module(Module m);
int select_all_modules();
int update_module(int id, Module updated);
int delete_module(int id);
int get_active_modules();
int get_modules_by_level(int level);

// Qo‘shiladi:
void show_modules_with_last_status_1();
void move_module_to_level_cell();

#endif
