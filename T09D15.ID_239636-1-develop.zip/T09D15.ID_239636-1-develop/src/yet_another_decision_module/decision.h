// src/yet_another_decision_module/decision.h

#ifndef DECISION_H
#define DECISION_H

#define GOLDEN_RATIO 0.666

int make_decision(double *data, int n);

#endif

