// ====== src/yet_another_decision_module/yet_another_decision_module_entry.c ======
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "../data_libs/data_io.h"
#include "../data_libs/data_stat.h"
#include "decision.h"

int main() {
    double *data;
    int n;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    data = (double *)malloc(n * sizeof(double));
    if (!data) {
        printf("Memory allocation failed!\n");
        return 1;
    }

    input(data, n);

    if (make_decision(data, n))
        printf("YES\n");
    else
        printf("NO\n");

    free(data);
    return 0;
}
