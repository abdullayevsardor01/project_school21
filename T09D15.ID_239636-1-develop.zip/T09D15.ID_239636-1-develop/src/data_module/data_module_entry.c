// ====== src/data_module/data_module_entry.c ======
#include <stdio.h>
#include <stdlib.h>

#include "../data_libs/data_io.h"
#include "../data_module/data_process.h"

int main() {
    double *data;
    int n;

    printf("Enter number of elements: ");
    scanf("%d", &n);

    data = (double *)malloc(n * sizeof(double));
    if (!data) {
        printf("Memory allocation failed!\n");
        return 1;
    }

    input(data, n);

    if (normalization(data, n))
        output(data, n);
    else
        printf("ERROR\n");

    free(data);
    return 0;
}
