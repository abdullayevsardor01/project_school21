// src/data_module/data_process.h

#ifndef DATA_PROCESS_H
#define DATA_PROCESS_H

void process_data(double *data, int size);

#endif
