// src/data_module/data_process.c

#include "data_process.h"

#include "../data_libs/data_stat.h"

void process_data(double *data, int size) {
    double mean = mean_value(data, size);
    double stddev = standard_deviation(data, size);

    for (int i = 0; i < size; i++) {
        data[i] = (data[i] - mean) / stddev;
    }
}
