#ifndef DATA_IO_H
#define DATA_IO_H

#include <stdbool.h>

bool input_data(double *data, int *size);
void output_data(const double *data, int size);

#endif
