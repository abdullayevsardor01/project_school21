#include "data_stat.h"

#include <math.h>
#ifndef DATA_STAT_H
#define DATA_STAT_H

double mean_value(const double *data, int size) {
    double sum = 0;
    for (int i = 0; i < size; i++) {
        sum += data[i];
    }
    return sum / size;
}

double standard_deviation(const double *data, int size) {
    double mean = mean_value(data, size);
    double sum = 0;
    for (int i = 0; i < size; i++) {
        sum += (data[i] - mean) * (data[i] - mean);
    }
    return sqrt(sum / size);
}

#endif
