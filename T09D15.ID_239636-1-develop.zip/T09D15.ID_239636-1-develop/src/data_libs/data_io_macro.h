// ====== src/data_libs/data_io_macro.h ======
#ifndef DATA_IO_MACRO_H
#define DATA_IO_MACRO_H

#include <stdio.h>

#define INPUT_ARRAY(type, arr, n)         \
    do {                                  \
        for (int i = 0; i < n; i++) {     \
            printf("Enter [%d]: ", i);    \
            scanf("%" #type, &arr[i]);    \
        }                                 \
    } while (0)

#define OUTPUT_ARRAY(type, arr, n)        \
    do {                                  \
        for (int i = 0; i < n; i++)       \
            printf("%" #type " ", arr[i]);\
        printf("\n");                     \
    } while (0)

#endif
