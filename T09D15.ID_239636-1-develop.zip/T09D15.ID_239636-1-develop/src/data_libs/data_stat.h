#ifndef DATA_STAT_H
#define DATA_STAT_H

double mean_value(const double *data, int size);
double standard_deviation(const double *data, int size);

#endif
