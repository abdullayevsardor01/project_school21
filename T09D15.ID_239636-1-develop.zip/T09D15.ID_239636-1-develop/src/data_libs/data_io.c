#include "data_io.h"

#include <stdio.h>

bool input_data(double *data, int *size) {
    printf("Nechta son kiritmoqchisiz: ");
    scanf("%d", size);

    if (*size <= 0 || *size > 100) return false;

    printf("Sonlarni kiriting:\n");
    for (int i = 0; i < *size; i++) {
        scanf("%lf", &data[i]);
    }
    return true;
}

void output_data(const double *data, int size) {
    printf("Natija:\n");
    for (int i = 0; i < size; i++) {
        printf("%.2f ", data[i]);
    }
    printf("\n");
}
