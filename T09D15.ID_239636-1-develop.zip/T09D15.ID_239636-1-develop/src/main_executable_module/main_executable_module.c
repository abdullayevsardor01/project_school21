// src/main_executable_module/main_executable_module.c

#include <math.h>  // sqrt() funksiyasi uchun
#include <stdio.h>

#include "../data_libs/data_io.h"                     // input, output funksiyalari uchun
#include "../data_libs/data_stat.h"                   // max, min, mean, variance uchun
#include "../data_module/data_process.h"              // normalization funksiyasi uchun
#include "../yet_another_decision_module/decision.h"  // GOLDEN_RATIO uchun

void sort(double *data, int n);  // Agar sort funksiyangiz mavjud bo‘lsa, header qo‘shing yoki e’lon qiling

void main() {
    int n = 5;  // Sinov uchun doimiy qiymat (asosiy versiyada foydalanuvchidan olish mumkin)
    double data_array[5] = {1.0, 2.0, 3.0, 4.0, 5.0};  // Misol uchun oddiy massiv
    double *data = data_array;

    printf("LOAD DATA...\n");
    input(data, n);

    printf("RAW DATA:\n\t");
    output(data, n);

    printf("\nNORMALIZED DATA:\n\t");
    normalization(data, n);
    output(data, n);

    printf("\nSORTED NORMALIZED DATA:\n\t");
    sort(data, n);
    output(data, n);

    printf("\nFINAL DECISION:\n\t");
    if (make_decision(data, n))
        printf("YES");
    else
        printf("NO");
}
