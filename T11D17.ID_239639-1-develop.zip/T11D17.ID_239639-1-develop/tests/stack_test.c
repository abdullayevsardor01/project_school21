#include "../src/stack.h"
#include <stdio.h>

int main() {
  stack_node *s = init();

  if (push(&s, 5) != SUCCESS)
    return FAIL;
  if (push(&s, 10) != SUCCESS)
    return FAIL;

  int val;
  if (pop(&s, &val) != SUCCESS || val != 10)
    return FAIL;
  if (pop(&s, &val) != SUCCESS || val != 5)
    return FAIL;

  destroy(s);
  return SUCCESS;
}
