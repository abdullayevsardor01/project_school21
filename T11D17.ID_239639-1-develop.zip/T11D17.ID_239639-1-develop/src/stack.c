#include "stack.h"

#include <stdlib.h>

stack_node *init() { return NULL; }

int push(stack_node **top, int val) {
    stack_node *n = malloc(sizeof(stack_node));
    if (!n) return FAIL;
    n->value = val;
    n->next = *top;
    *top = n;
    return SUCCESS;
}

int pop(stack_node **top, int *val) {
    if (!top || !(*top)) return FAIL;
    stack_node *tmp = *top;
    *val = tmp->value;
    *top = tmp->next;
    free(tmp);
    return SUCCESS;
}

void destroy(stack_node *top) {
    while (top) {
        stack_node *tmp = top;
        top = top->next;
        free(tmp);
    }
}
