#ifndef STACK_H
#define STACK_H

#define SUCCESS 0
#define FAIL 1

typedef struct stack_node {
    int value;
    struct stack_node *next;
} stack_node;

stack_node* init();
int push(stack_node **top, int val);
int pop(stack_node **top, int *val);
void destroy(stack_node *top);

#endif
