#include "list.h"

#include <stdlib.h>

node *init(door *d) {
    node *n = malloc(sizeof(node));
    if (n) {
        n->data = *d;
        n->next = NULL;
    }
    return n;
}

node *add_door(node *elem, door *d) {
    if (!elem) return NULL;
    node *n = malloc(sizeof(node));
    if (n) {
        n->data = *d;
        n->next = elem->next;
        elem->next = n;
    }
    return n;
}

node *find_door(int id, node *root) {
    while (root) {
        if (root->data.id == id) return root;
        root = root->next;
    }
    return NULL;
}

node *remove_door(node *elem, node *root) {
    if (!root || !elem) return root;
    if (root == elem) {
        node *tmp = root->next;
        free(root);
        return tmp;
    }
    node *prev = root;
    while (prev->next && prev->next != elem) prev = prev->next;
    if (prev->next == elem) {
        prev->next = elem->next;
        free(elem);
    }
    return root;
}

void destroy(node *root) {
    while (root) {
        node *tmp = root;
        root = root->next;
        free(tmp);
    }
}
