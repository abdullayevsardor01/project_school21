#include "list.h"

#include <stdio.h>

#include "door_struct.h"

int main() {
    door d1 = {1, 0};
    door d2 = {2, 0};

    node *head = init(&d1);
    if (!head) return FAIL;

    node *added = add_door(head, &d2);
    if (!added || added->data.id != 2) return FAIL;

    node *found = find_door(2, head);
    if (!found || found->data.id != 2) return FAIL;

    head = remove_door(added, head);
    if (find_door(2, head)) return FAIL;

    destroy(head);
    return SUCCESS;
}
