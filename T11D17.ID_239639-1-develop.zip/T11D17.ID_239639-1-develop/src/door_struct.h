// src/door_struct.h
#ifndef DOOR_STRUCT_H
#define DOOR_STRUCT_H

typedef struct door {
    int id;
    int status;
} door;

#endif
