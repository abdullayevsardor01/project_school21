#ifndef LIST_H
#define LIST_H

#include "door_struct.h"

#define SUCCESS 0
#define FAIL 1

typedef struct node {
    door data;
    struct node *next;
} node;

node* init(door *d);
node* add_door(node *elem, door *d);
node* find_door(int id, node *root);
node* remove_door(node *elem, node *root);
void destroy(node *root);

#endif
