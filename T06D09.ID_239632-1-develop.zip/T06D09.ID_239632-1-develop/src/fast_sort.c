#include <stdio.h>

#define SIZE 10

int read_array(int *arr, int size);
void print_array(int *arr, int size);

// Quicksort
void quick_sort(int *arr, int left, int right);

// Heapsort
void heap_sort(int *arr, int size);
void heapify(int *arr, int size, int i);

void copy_array(int *src, int *dst, int size);

int main() {
    int original[SIZE];
    int arr1[SIZE], arr2[SIZE];

    if (!read_array(original, SIZE)) {
        printf("n/a\n");
        return 1;
    }

    copy_array(original, arr1, SIZE);
    copy_array(original, arr2, SIZE);

    quick_sort(arr1, 0, SIZE - 1);
    print_array(arr1, SIZE);  // 1-qatorda chiqadi

    heap_sort(arr2, SIZE);
    print_array(arr2, SIZE);  // 2-qatorda chiqadi

    return 0;
}

int read_array(int *arr, int size) {
    for (int i = 0; i < size; i++) {
        if (scanf("%d", &arr[i]) != 1) {
            return 0;
        }
    }
    return 1;
}

void print_array(int *arr, int size) {
    for (int i = 0; i < size; i++) {
        printf("%d", arr[i]);
        if (i < size - 1) printf(" ");
    }
    printf("\n");
}

void copy_array(int *src, int *dst, int size) {
    for (int i = 0; i < size; i++) {
        dst[i] = src[i];
    }
}

// ========== QUICK SORT ==========
void quick_sort(int *arr, int left, int right) {
    if (left >= right) return;

    int pivot = arr[(left + right) / 2];
    int i = left;
    int j = right;

    while (i <= j) {
        while (arr[i] < pivot) i++;
        while (arr[j] > pivot) j--;
        if (i <= j) {
            int tmp = arr[i];
            arr[i] = arr[j];
            arr[j] = tmp;
            i++;
            j--;
        }
    }

    if (left < j) quick_sort(arr, left, j);
    if (i < right) quick_sort(arr, i, right);
}

// ========== HEAP SORT ==========
void heap_sort(int *arr, int size) {
    // Max heap qurish
    for (int i = size / 2 - 1; i >= 0; i--) {
        heapify(arr, size, i);
    }

    // Elementlarni bittalab ajratish
    for (int i = size - 1; i > 0; i--) {
        int tmp = arr[0];
        arr[0] = arr[i];
        arr[i] = tmp;

        heapify(arr, i, 0);
    }
}

void heapify(int *arr, int size, int i) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < size && arr[left] > arr[largest]) largest = left;

    if (right < size && arr[right] > arr[largest]) largest = right;

    if (largest != i) {
        int tmp = arr[i];
        arr[i] = arr[largest];
        arr[largest] = tmp;

        heapify(arr, size, largest);
    }
}
