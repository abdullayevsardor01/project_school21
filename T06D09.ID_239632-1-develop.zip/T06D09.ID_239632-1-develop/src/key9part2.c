#include <stdio.h>

#define LEN 100

void sum(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length);
void sub(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length);
int is_bigger_or_equal(int *a, int len1, int *b, int len2);
void print_number(int *num, int len);
int read_number(int *buff);

int main() {
    int a[LEN] = {0}, b[LEN] = {0}, res[LEN + 1] = {0};
    int len1, len2, res_len;

    len1 = read_number(a);
    len2 = read_number(b);

    if (len1 == 0 || len2 == 0) {
        printf("n/a\n");
        return 0;
    }

    // Qo‘shish
    sum(a, len1, b, len2, res, &res_len);
    print_number(res, res_len);

    // Ayirish
    if (is_bigger_or_equal(a, len1, b, len2)) {
        sub(a, len1, b, len2, res, &res_len);
        print_number(res, res_len);
    } else {
        printf("n/a\n");
    }

    return 0;
}

int read_number(int *buff) {
    int temp[LEN];
    int n = 0;
    int ch;

    while ((ch = getchar()) != '\n' && ch != EOF) {
        if (ch == ' ') continue;  // Bo‘sh joylarni o‘tkazib yuboramiz
        if (ch >= '0' && ch <= '9') {
            if (n >= LEN) return 0;  // Chegaradan oshib ketmaslik
            temp[n++] = ch - '0';
        } else {
            return 0;  // Noto‘g‘ri belgi
        }
    }

    for (int i = 0; i < n; i++) buff[i] = temp[i];
    return n;
}

void print_number(int *num, int len) {
    int start = 0;
    while (start < len - 1 && num[start] == 0) start++;
    for (int i = start; i < len; i++) {
        printf("%d", num[i]);
        if (i < len - 1) printf(" ");
    }
    printf("\n");
}

void sum(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length) {
    int i = len1 - 1;
    int j = len2 - 1;
    int k = LEN;
    int carry = 0;
    int temp[LEN + 1] = {0};

    while (i >= 0 || j >= 0 || carry > 0) {
        int d1 = (i >= 0) ? buff1[i] : 0;
        int d2 = (j >= 0) ? buff2[j] : 0;
        int s = d1 + d2 + carry;
        temp[--k] = s % 10;
        carry = s / 10;
        i--;
        j--;
    }

    *result_length = LEN - k;
    for (int t = 0; t < *result_length; t++) {
        result[t] = temp[k + t];
    }
}

void sub(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length) {
    int i = len1 - 1;
    int j = len2 - 1;
    int k = LEN;
    int borrow = 0;
    int temp[LEN] = {0};

    while (i >= 0) {
        int d1 = buff1[i];
        int d2 = (j >= 0) ? buff2[j] : 0;
        int s = d1 - d2 - borrow;
        if (s < 0) {
            s += 10;
            borrow = 1;
        } else {
            borrow = 0;
        }
        temp[--k] = s;
        i--;
        j--;
    }

    // Remove leading zeros
    while (k < LEN - 1 && temp[k] == 0) {
        k++;
    }

    *result_length = LEN - k;
    for (int t = 0; t < *result_length; t++) {
        result[t] = temp[k + t];
    }
}

int is_bigger_or_equal(int *a, int len1, int *b, int len2) {
    if (len1 > len2) return 1;
    if (len1 < len2) return 0;
    for (int i = 0; i < len1; i++) {
        if (a[i] > b[i]) return 1;
        if (a[i] < b[i]) return 0;
    }
    return 1;  // Teng bo‘lsa, ham true
}
