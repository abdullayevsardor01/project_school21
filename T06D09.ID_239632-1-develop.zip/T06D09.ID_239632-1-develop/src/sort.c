#include <stdio.h>

#define SIZE 10

int read_array(int *arr, int size);
void sort_array(int *arr, int size);
void print_array(int *arr, int size);

int main() {
    int arr[SIZE];

    if (!read_array(arr, SIZE)) {
        printf("n/a\n");
        return 1;
    }

    sort_array(arr, SIZE);
    print_array(arr, SIZE);

    return 0;
}

int read_array(int *arr, int size) {
    for (int i = 0; i < size; i++) {
        if (scanf("%d", &arr[i]) != 1) {
            return 0;  // noto‘g‘ri kiritish
        }
    }
    return 1;
}

void sort_array(int *arr, int size) {
    // Oddiy Bubble Sort algoritmi
    for (int i = 0; i < size - 1; i++) {
        for (int j = 0; j < size - 1 - i; j++) {
            if (arr[j] > arr[j + 1]) {
                // joylarni almashtirish
                int tmp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = tmp;
            }
        }
    }
}

void print_array(int *arr, int size) {
    for (int i = 0; i < size; i++) {
        printf("%d", arr[i]);
        if (i < size - 1) {
            printf(" ");
        }
    }
    printf("\n");
}
