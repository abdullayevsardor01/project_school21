#include <stdio.h>

#define MAX_SIZE 10

void input(int *buffer, int *length);
void output(int *buffer, int length);
int sum_numbers(int *buffer, int length);
int find_numbers(int *buffer, int length, int number, int *numbers);

int main() {
    int buffer[MAX_SIZE];
    int result[MAX_SIZE];
    int length;

    input(buffer, &length);

    if (length <= 0 || length > MAX_SIZE) {
        printf("n/a");
        return 0;
    }

    int sum = sum_numbers(buffer, length);

    if (sum == 0) {
        printf("n/a");
        return 0;
    }

    printf("%d\n", sum);

    int result_len = find_numbers(buffer, length, sum, result);

    if (result_len == 0) {
        printf("n/a");
        return 0;
    }

    output(result, result_len);

    return 0;
}

// Massiv va uning uzunligini stdin orqali oladi
void input(int *buffer, int *length) {
    if (scanf("%d", length) != 1) *length = -1;

    for (int i = 0; i < *length; i++) {
        if (scanf("%d", &buffer[i]) != 1) {
            *length = -1;
            break;
        }
    }
}

// Juft elementlar yig‘indisini hisoblaydi
int sum_numbers(int *buffer, int length) {
    int sum = 0;
    int found = 0;

    for (int i = 0; i < length; i++) {
        if (buffer[i] % 2 == 0) {
            sum += buffer[i];
            found = 1;
        }
    }

    if (!found) return 0;

    return sum;
}

// Sum ga qoldiqsiz bo‘linadigan elementlarni topadi
int find_numbers(int *buffer, int length, int number, int *numbers) {
    int count = 0;

    for (int i = 0; i < length; i++) {
        if (buffer[i] != 0 && number % buffer[i] == 0) {
            numbers[count++] = buffer[i];
        }
    }

    return count;
}

// Massivni chiqarish
void output(int *buffer, int length) {
    for (int i = 0; i < length; i++) {
        printf("%d", buffer[i]);
        if (i != length - 1) printf(" ");
    }
}
