#include <stdio.h>

#define MAX_SIZE 10

int input(int *array, int *n, int *shift);
void output(int *array, int n);
void left_shift(int *array, int n, int shift);
void right_shift(int *array, int n, int shift);

int main() {
    int array[MAX_SIZE];
    int n, shift;

    if (!input(array, &n, &shift)) {
        printf("n/a\n");
        return 0;
    }

    if (shift >= 0) {
        left_shift(array, n, shift % n);
    } else {
        right_shift(array, n, (-shift) % n);
    }

    output(array, n);

    return 0;
}

int input(int *array, int *n, int *shift) {
    if (scanf("%d", n) != 1 || *n <= 0 || *n > MAX_SIZE) {
        return 0;
    }

    for (int i = 0; i < *n; i++) {
        if (scanf("%d", &array[i]) != 1) {
            return 0;
        }
    }

    if (scanf("%d", shift) != 1) {
        return 0;
    }

    return 1;
}

void output(int *array, int n) {
    for (int i = 0; i < n; i++) {
        printf("%d", array[i]);
        if (i != n - 1) printf(" ");
    }
    printf("\n");
}

void left_shift(int *array, int n, int shift) {
    int temp[MAX_SIZE];

    for (int i = 0; i < n; i++) {
        temp[i] = array[(i + shift) % n];
    }

    for (int i = 0; i < n; i++) {
        array[i] = temp[i];
    }
}

void right_shift(int *array, int n, int shift) {
    int temp[MAX_SIZE];

    for (int i = 0; i < n; i++) {
        temp[i] = array[(i - shift + n) % n];
    }

    for (int i = 0; i < n; i++) {
        array[i] = temp[i];
    }
}
