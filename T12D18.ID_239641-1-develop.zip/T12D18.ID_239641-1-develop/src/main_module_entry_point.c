#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "documentation_module.h"
#include "print_module.h"

char my_putchar(char c) {
    write(1, &c, 1);
    return c;
}

void print_doc_availability(char* name, int is_available) {
    char buffer[100];
    snprintf(buffer, sizeof(buffer), "[%-15s: %s]\n", name, is_available ? "available" : "unavailable");
    for (int i = 0; buffer[i]; i++) my_putchar(buffer[i]);
}

int main() {
    char* docs[] = {"Linked lists", "Queues", "Maps", "Binary Trees"};
    int* mask =
        check_available_documentation_module(validate, DOCUMENTS_COUNT, docs[0], docs[1], docs[2], docs[3]);

    for (int i = 0; i < DOCUMENTS_COUNT; i++) {
        print_doc_availability(docs[i], mask[i]);
    }

    free(mask);
    return 0;
}
