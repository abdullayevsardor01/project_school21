#include <stdio.h>

#include "bst.h"

int cmp(int a, int b) { return a - b; }

void print_item(int n) { printf("%d ", n); }

int main() {
    t_btree* root = bstree_create_node(10);
    bstree_insert(root, 5, cmp);
    bstree_insert(root, 15, cmp);
    bstree_insert(root, 3, cmp);
    bstree_insert(root, 7, cmp);

    printf("Infix: ");
    bstree_apply_infix(root, print_item);
    printf("\n");

    printf("Prefix: ");
    bstree_apply_prefix(root, print_item);
    printf("\n");

    printf("Postfix: ");
    bstree_apply_postfix(root, print_item);
    printf("\n");

    return 0;
}
