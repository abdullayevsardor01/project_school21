#include <stdio.h>
#include <stdlib.h>

#include "bst.h"

int main() {
    t_btree* n1 = bstree_create_node(10);
    t_btree* n2 = bstree_create_node(20);

    if (n1) printf("Node1: %d\n", n1->item);
    if (n2) printf("Node2: %d\n", n2->item);

    free(n1);
    free(n2);
    return 0;
}
