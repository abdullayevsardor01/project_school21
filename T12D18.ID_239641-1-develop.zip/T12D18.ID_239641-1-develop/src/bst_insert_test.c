#include <stdio.h>
#include <stdlib.h>

#include "bst.h"

int cmp(int a, int b) { return a - b; }

int main() {
    t_btree* root = bstree_create_node(10);
    bstree_insert(root, 5, cmp);
    bstree_insert(root, 15, cmp);
    bstree_insert(root, 12, cmp);

    printf("Tree root: %d\n", root->item);
    printf("Left child: %d\n", root->left->item);
    printf("Right child: %d\n", root->right->item);
    return 0;
}
