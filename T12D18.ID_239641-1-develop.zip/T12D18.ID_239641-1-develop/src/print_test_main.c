#include <unistd.h>

#include "print_module.h"

char my_putchar(char c) {
    write(1, &c, 1);
    return c;
}

int main() {
    print_log(my_putchar, "System booted");
    return 0;
}
