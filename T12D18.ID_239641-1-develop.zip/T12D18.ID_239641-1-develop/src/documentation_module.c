#include "documentation_module.h"

#include <stdarg.h>
#include <stdlib.h>
#include <string.h>

int* check_available_documentation_module(int (*validate)(char*), int document_count, ...) {
    va_list args;
    va_start(args, document_count);

    int* results = malloc(sizeof(int) * document_count);
    if (!results) return NULL;

    for (int i = 0; i < document_count; i++) {
        char* doc = va_arg(args, char*);
        results[i] = validate(doc);
    }

    va_end(args);
    return results;
}

int validate(char* data) { return strcmp(data, AVAILABLE_DOCUMENT) == 0; }
