#ifndef PRINT_MODULE_H
#define PRINT_MODULE_H

void print_log(char (*print)(char), char* message);

#endif
