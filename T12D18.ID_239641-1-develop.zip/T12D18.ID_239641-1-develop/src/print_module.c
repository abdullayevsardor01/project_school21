#include <string.h>
#include <time.h>

void print_log(char (*print)(char), char* message) {
    char buffer[256];
    time_t now = time(NULL);
    struct tm* timeinfo = localtime(&now);
    char time_str[9];  // "HH:MM:SS"

    strftime(time_str, sizeof(time_str), "%H:%M:%S", timeinfo);

    strcpy(buffer, "[LOG] ");
    strcat(buffer, time_str);
    strcat(buffer, " ");
    strcat(buffer, message);

    for (int i = 0; buffer[i]; i++) {
        print(buffer[i]);
    }
}
