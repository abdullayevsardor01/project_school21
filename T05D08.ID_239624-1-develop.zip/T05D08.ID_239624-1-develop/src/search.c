#include <math.h>
#include <stdio.h>
#define NMAX 30

int input(int *a, int *n);
double mean(int *a, int n);
double variance(int *a, int n);
int is_valid(int x, double mean, double sigma);

int main() {
    int n, data[NMAX];

    if (!input(data, &n)) {
        printf("n/a\n");
        return 1;
    }

    double m = mean(data, n);
    double s = sqrt(variance(data, n));

    for (int i = 0; i < n; i++) {
        if (is_valid(data[i], m, s)) {
            printf("%d\n", data[i]);
            return 0;
        }
    }

    printf("0\n");
    return 0;
}

int input(int *a, int *n) {
    if (scanf("%d", n) != 1 || *n < 1 || *n > NMAX) return 0;

    for (int i = 0; i < *n; i++) {
        if (scanf("%d", &a[i]) != 1) return 0;
    }

    return 1;
}

double mean(int *a, int n) {
    double sum = 0;
    for (int i = 0; i < n; i++) sum += a[i];
    return sum / n;
}

double variance(int *a, int n) {
    double m = mean(a, n);
    double sum = 0;
    for (int i = 0; i < n; i++) {
        double d = a[i] - m;
        sum += d * d;
    }
    return sum / n;
}

int is_valid(int x, double m, double s) { return x != 0 && x % 2 == 0 && x >= m && fabs(x - m) <= 3 * s; }
