#include "s21_string.h"

void test_strlen() { printf("strlen('abc') = %zu\n", s21_strlen("abc")); }

void test_strcmp() {
    printf("strcmp('abc', 'abc') = %d\n", s21_strcmp("abc", "abc"));
    printf("strcmp('abc', 'abd') = %d\n", s21_strcmp("abc", "abd"));
}

void test_strcpy() {
    char dest[20];
    printf("strcpy -> %s\n", s21_strcpy(dest, "hello"));
}

void test_strcat() {
    char dest[20] = "Hi, ";
    printf("strcat -> %s\n", s21_strcat(dest, "there"));
}

void test_strchr() {
    char *res = s21_strchr("hello", 'l');
    printf("strchr -> %s\n", res);
}

void test_strstr() {
    char *res = s21_strstr("hello world", "wor");
    printf("strstr -> %s\n", res);
}

void test_strtok() {
    char str[] = "a,b,c";
    char *token = s21_strtok(str, ",");
    while (token) {
        printf("Token: %s\n", token);
        token = s21_strtok(NULL, ",");
    }
}

int main() {
    test_strlen();
    test_strcmp();
    test_strcpy();
    test_strcat();
    test_strchr();
    test_strstr();
    test_strtok();
    return 0;
}
