#include "s21_string.h"

// Quest 1: s21_strlen
// Bu funksiya satr uzunligini hisoblaydi. '' belgigacha sanaydi.
size_t s21_strlen(const char *str) {
    size_t len = 0;
    while (str && *str++) len++;
    return len;
}

// Quest 2: s21_strcmp
// Bu funksiya ikki satrni taqqoslaydi. Teng bo‘lsa 0, farq bo‘lsa musbat/manfiy qiymat qaytaradi.
int s21_strcmp(const char *str1, const char *str2) {
    while (*str1 && (*str1 == *str2)) {
        str1++;
        str2++;
    }
    return *(unsigned char *)str1 - *(unsigned char *)str2;
}

// Quest 3: s21_strcpy
// src satrini dest'ga nusxalaydi, oxirida '' bilan tugaydi.
char *s21_strcpy(char *dest, const char *src) {
    char *ret = dest;
    while ((*dest++ = *src++));
    return ret;
}

// Quest 4: s21_strcat
// dest satrining oxiriga src satrini biriktiradi.
char *s21_strcat(char *dest, const char *src) {
    char *ret = dest;
    while (*dest) dest++;
    while ((*dest++ = *src++));
    return ret;
}

// Quest 5: s21_strchr
// str satrida c belgining birinchi uchrashgan joyini topadi, pointer qaytaradi.
char *s21_strchr(const char *str, int c) {
    while (*str) {
        if (*str == (char)c) return (char *)str;
        str++;
    }
    return c == '\0' ? (char *)str : NULL;
}

// Quest 6: s21_strstr
// haystack ichida needle substringni qidiradi. Topilsa pointer qaytaradi.
char *s21_strstr(const char *haystack, const char *needle) {
    if (!*needle) return (char *)haystack;
    for (; *haystack; haystack++) {
        const char *h = haystack, *n = needle;
        while (*h && *n && *h == *n) {
            h++;
            n++;
        }
        if (!*n) return (char *)haystack;
    }
    return NULL;
}

// Quest 7: s21_strtok
// str satrini delim belgilariga qarab bo‘laklarga ajratadi. Har chaqiriqda keyingi tokenni qaytaradi.
// Quest 7: s21_strtok
char *s21_strtok(char *str, const char *delim) {
    static char *next;
    if (str) next = str;
    if (!next) return NULL;

    while (*next && s21_strchr(delim, *next)) next++;
    if (!*next) return NULL;

    char *start = next;
    while (*next && !s21_strchr(delim, *next)) next++;
    if (*next)
        *next++ = '\0';
    else
        next = NULL;

    return start;
}

char *strchr(const char *str, int c) {  // helper for strtok
    while (*str) {
        if (*str == (char)c) return (char *)str;
        str++;
    }
    return NULL;
}
