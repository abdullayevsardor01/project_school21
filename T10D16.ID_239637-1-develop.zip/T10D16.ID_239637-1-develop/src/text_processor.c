#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Quest 8*: text_processor -w
// Bu dastur -w parametri bilan satrni kenglik bo‘yicha formatlaydi.
int main(int argc, char *argv[]) {
    if (argc != 2 || strcmp(argv[1], "-w") != 0) {
        printf("n/a\n");
        return 1;
    }

    int width;
    scanf("%d", &width);
    getchar();  // \n belgini olib tashlaydi

    char text[101];
    fgets(text, sizeof(text), stdin);  // Satrni to‘liq o‘qish

    // So‘zlarni ajratish
    char *words[50];
    int count = 0;
    char *tok = strtok(text, " \n");
    while (tok) {
        words[count++] = tok;
        tok = strtok(NULL, " \n");
    }

    for (int i = 0; i < count;) {
        int line_len = 0, j = i;
        while (j < count && (size_t)(line_len + strlen(words[j]) + (j - i)) <= (size_t)width) {
            line_len += strlen(words[j]);
            j++;
        }

        int gaps = j - i - 1;
        int spaces = (gaps > 0) ? (width - line_len) / gaps : 0;
        int extra = (gaps > 0) ? (width - line_len) % gaps : 0;

        for (int k = i; k < j; k++) {
            printf("%s", words[k]);
            if (k < j - 1) {
                for (int s = 0; s < spaces + (k - i < extra); s++) printf(" ");
            }
        }

        printf("\n");
        i = j;
    }

    return 0;
}
