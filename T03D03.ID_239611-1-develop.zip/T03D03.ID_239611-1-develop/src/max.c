#include <stdio.h>

int max(int x, int y) {
  return (x > y) ? x : y;
}

int main(void) {
  int a, b;
  if (scanf("%d %d", &a, &b) != 2) {
    printf("n/a\n");
    return 1;
  }

  printf("%d\n", max(a, b));
  return 0;
}
