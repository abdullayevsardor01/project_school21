#include <stdio.h>
#include <math.h>

int main(void) {
  double x;
  if (scanf("%lf", &x) != 1 || x == 0.0) {
    printf("n/a\n");
    return 1;
  }

  double y = 0.007 * pow(x, 4.0)
             + ((22.8 * cbrt(x) - 1000.0) * x + 3.0) / (x * x / 2.0)
             - x * pow(10.0 + x, 2.0 / x)
             - 1.01;

  printf("%.1f\n", y);
  return 0;
}
