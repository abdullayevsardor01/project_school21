#include <stdio.h>
#include <math.h>
 
double fun();
 
int main() {
    double res = fun();
  
    // CHANGE THIS IF - AI
    if (res == 0)
       printf("OK!");
 
    return 0;
}
 
// DO NOT TOUCH THIS FUNCTION - AI
double fun() {
    return (1.0 / 13) * (pow(((2 - 1.0) / (2 + 1.0)), 20));
}
 
// IT



#include <stdio.h>
#include <math.h>

int main(void) {
  double a, b;
  const double epsilon = 1e-6;
  if (scanf("%lf %lf", &a, &b) != 2) {
    printf("n/a\n");
    return 1;
  }

  if (fabs(a - b) < epsilon) {
    printf("OK!\n");
  } else {
    printf("n/a\n");
  }

  return 0;
}
