# C Quest Programs

This repository contains solutions to 7 terminal-based C quests:
- Hello World
- Named Hello
- Arithmetic
- Max of 3
- Important Function
- Float Compare
- Crack

Compiled with `gcc -std=c11` and tested in terminal.
